-- This is the left most column

  -- It is ok top-level declarations to start in any columns
  firstGoodIndentation = 1

  -- Just that the following ones must start from this column too
  secondGoodIndentation = 2
