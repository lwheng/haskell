data Bool = False | True
