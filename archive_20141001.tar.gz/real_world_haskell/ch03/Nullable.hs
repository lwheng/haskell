-- Maybe monad simple examples
someBool = Just True

someString = Just "something"

wrapped = Just (Just "wrapped")
