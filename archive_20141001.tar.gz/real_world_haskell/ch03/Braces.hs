foo = let { a=1; b=2; c=3 }
      in
        a+b+c

-- explicit structuring, using semi-colon
-- but it ain't the Haskell way. not cool
