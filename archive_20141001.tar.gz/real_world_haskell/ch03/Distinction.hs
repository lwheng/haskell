a = ("Porpoise", "Grey")
b = ("Table", "Oak")

data Cetacean = Cetacean String String
data Furniture = Furniture String String

-- Because they have different type name and constructor, they are not the same even though they are both
-- <...> String String
