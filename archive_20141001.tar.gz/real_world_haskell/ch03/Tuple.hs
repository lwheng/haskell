-- Simple tuple examples

third (a, b, c) = c

complicated (True, a, x:xs, 5) = (a, xs)
