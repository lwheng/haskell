-- This is the left most column

  -- first declaration
  firstBadIndentation = 1

-- second declaration. notice the indentation is to the left
-- will cause a parse error
secondBadIndentation = 2
