-- pretty obvious
-- define variable this way, and you can access it anywhere
itemName = "Weighted Companion Cube"

