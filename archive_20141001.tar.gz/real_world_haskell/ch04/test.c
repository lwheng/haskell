#define DLT_EN10MB  1   /* Ethernet (10Mb) */
#define DLT_EN3MB   2   /* Experiemtal Ethernet (3Mb) */
#define DLT_AX25    3   /* Amateur Radio AX.5 */
