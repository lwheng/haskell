lastButOne :: [a] -> a

lastButOne xs = last (init xs)
