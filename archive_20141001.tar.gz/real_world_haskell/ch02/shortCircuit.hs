newOr a b = if a then a else b
