add a b = a + b
