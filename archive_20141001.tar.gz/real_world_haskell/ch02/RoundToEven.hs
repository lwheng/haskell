isOdd n = mod n 2 == 1
