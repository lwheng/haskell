take :: Int -> ([a] -> [a])


